import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plane, Building, Play, X, TrendingUp } from 'lucide-react';
import { RoiCalculator } from './ui/RoiCalculator';

interface GlobalInvestorsProps {
  isGlobal: boolean;
}

export const GlobalInvestors: React.FC<GlobalInvestorsProps> = ({ isGlobal }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const videoId = "UJggNYnR8lQ";

  return (
    <section className="py-24 bg-slate-900 text-white border-t border-slate-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
        >
          <span className="text-gold-500 font-bold tracking-wider uppercase text-sm flex items-center justify-center gap-2">
            <Plane size={16} /> {isGlobal ? "Oportunidades Globales" : "Global Opportunities"}
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mt-2">
            {isGlobal ? "Invierta en Madrid." : "Invest in Madrid."} <span className="text-gold-500">{isGlobal ? "Gane en Euros." : "Earn in Euros."}</span>
          </h2>
          <p className="mt-4 text-xl text-slate-400 max-w-3xl mx-auto">
            {isGlobal 
              ? "Diversifique su portafolio con oportunidades de pre-construcción en Hotel 101. Un modelo de inversión de ingresos pasivos completamente libre de gestión."
              : "Diversify your portfolio with Hotel 101 pre-construction opportunities. A completely hands-off, high-yield passive income investment model."
            }
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Video Feature - Click to Play */}
            <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="space-y-6"
            >
                <div 
                    className="group relative rounded-2xl overflow-hidden shadow-2xl bg-black border border-slate-700 cursor-pointer"
                    onClick={() => setIsPlaying(true)}
                >
                    {/* 16:9 Aspect Ratio Container */}
                    <div className="relative w-full pt-[56.25%]">
                        <img 
                            src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`} 
                            alt="Hotel 101 Madrid" 
                            className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity duration-500"
                        />
                         <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-16 h-16 bg-gold-500/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                                <Play className="w-8 h-8 text-white fill-current ml-1" />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex items-start space-x-4 p-4 bg-slate-800 rounded-xl">
                    <TrendingUp className="text-gold-500 w-6 h-6 mt-1 flex-shrink-0" />
                    <div>
                        <h4 className="font-bold text-lg">Hotel 101 Model</h4>
                        <p className="text-slate-400 text-sm">Consistent revenue sharing regardless of room occupancy. The hassle-free way to own global real estate.</p>
                    </div>
                </div>
            </motion.div>

            {/* ROI Calculator */}
            <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
            >
                <RoiCalculator />
            </motion.div>
        </div>
      </div>

      {/* Video Modal */}
      <AnimatePresence>
        {isPlaying && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex items-center justify-center p-4"
                onClick={() => setIsPlaying(false)}
            >
                <div className="relative w-full max-w-5xl aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-700">
                    <button 
                        className="absolute top-4 right-4 z-50 bg-white/10 hover:bg-white/20 p-2 rounded-full text-white transition-colors"
                        onClick={(e) => { e.stopPropagation(); setIsPlaying(false); }}
                    >
                        <X size={24} />
                    </button>
                    <iframe 
                        src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`} 
                        title="Video Player"
                        className="absolute inset-0 w-full h-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowFullScreen
                    ></iframe>
                </div>
            </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};