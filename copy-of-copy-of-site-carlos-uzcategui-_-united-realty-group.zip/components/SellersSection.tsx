import React from 'react';
import { Star, Camera, BrainCircuit, Globe2, Network } from 'lucide-react';
import { motion } from 'framer-motion';

const REVIEWS = [
    { id: 1, name: "Vivian Sidi", text: "Carlos offers exceptional, custom tailored, personal and professional services. I had the pleasure of having Carlos represent me in multiple real estate transactions and am impressed and satisfied with his caliber of work.", stars: 5 },
    { id: 2, name: "Juan José Maya", text: "This was our first time buying a house... He expertly guided us through the whole process. He was our advocate in every decision we had to make, and went above and beyond.", stars: 5 },
    { id: 3, name: "Jose Gallardo (SOFDAV)", text: "Thanks to his amazing negotiating skills this last home sold close to 15%+ over appraisal value after a multiple offer scenario.", stars: 5 },
    { id: 4, name: "Karim Mamri", text: "Carlos exceeded all our expectations by his knowledge of the market and his art of negotiation. He assisted us on all steps From the initial showing to the final closing.", stars: 5 },
    { id: 5, name: "Raimundo Vazquez", text: "Amazing negotiating skills and professional work on time with a 1031 exchange that was wonderfully done, sold a retail property (KFC tenant) Bought both this house and another.", stars: 5 },
    { id: 6, name: "Oswaldo Machado", text: "As an engineer leading a team, I appreciate meticulous attention to detail, and Carlos exemplifies this... negotiation skills are unparalleled.", stars: 5 },
    { id: 7, name: "Maria Isabel Onate", text: "His passion for his work and his genuine desire to help his clients achieve their real estate goals makes him a standout in the industry.", stars: 5 },
];

const LOGOS = [
    "https://upload.wikimedia.org/wikipedia/commons/d/d4/Zillow_Wordmark.svg",
    "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Realtor.com_Logo.svg/1024px-Realtor.com_Logo.svg.png",
    "https://s.yimg.com/cv/apiv2/default/20201020/WSJ_black.png",
    "https://list.juwai.com/sites/default/files/images/juwai-ltd-logo.png",
    "https://upload.wikimedia.org/wikipedia/commons/8/87/Homes_com_Logo.png"
];

export const SellersSection: React.FC = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 mb-16 text-center">
        <h2 className="text-4xl font-bold text-slate-900 mb-4">The Marketing Machine</h2>
        <p className="text-slate-500 text-lg">Exposure on the world's most premium platforms, enhanced by modern technology.</p>
      </div>

      {/* AI & Tech Features */}
      <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-3 gap-8 mb-20">
        <motion.div whileHover={{ y: -5 }} className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <BrainCircuit className="w-10 h-10 text-gold-500 mb-4" />
            <h3 className="font-bold text-xl text-slate-900 mb-2">AI-Powered Targeting</h3>
            <p className="text-slate-600">We use predictive analytics to identify buyers before they even start searching, matching your home's profile to their behavior.</p>
        </motion.div>
        
        <motion.div whileHover={{ y: -5 }} className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <Camera className="w-10 h-10 text-gold-500 mb-4" />
            <h3 className="font-bold text-xl text-slate-900 mb-2">Cinematic Media</h3>
            <p className="text-slate-600">4K HDR Photography, Drone Aerials, and immersive 3D tours are standard. We don't just list homes; we premiere them.</p>
        </motion.div>
        
        <motion.div whileHover={{ y: -5 }} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-gold-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg uppercase tracking-wider">
                Massive Reach
            </div>
            <Globe2 className="w-10 h-10 text-gold-500 mb-4" />
            <h3 className="font-bold text-xl text-slate-900 mb-2">Global & National Reach</h3>
            <p className="text-slate-600 mb-3">Your property is translated and broadcast to <span className="font-bold text-slate-900">200+ national and international portals</span>, including Juwai (China), Zillow, Homes.com, and Wall Street Journal Global.</p>
            
            <div className="mt-4 pt-4 border-t border-slate-200 flex items-start space-x-2">
                <Network className="w-4 h-4 text-gold-600 mt-1" />
                <p className="text-xs text-slate-500 font-semibold">Affiliated with <span className="text-gold-600">260+ Real Estate Agent Associations</span> worldwide.</p>
            </div>
        </motion.div>
      </div>

      {/* Infinite Logo Ticker */}
      <div className="relative w-full overflow-hidden bg-slate-50 py-12 border-y border-slate-100 mb-20">
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-slate-50 to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-slate-50 to-transparent z-10" />
        
        {/* Container width must be large enough to hold all items. Animation translates -50%. */}
        <div className="flex w-[max-content] animate-scroll">
            {/* Duplicate the array 6 times to ensure seamless scrolling on all screens */}
            {[...LOGOS, ...LOGOS, ...LOGOS, ...LOGOS, ...LOGOS, ...LOGOS].map((src, index) => (
                <div key={index} className="mx-8 md:mx-16 flex justify-center items-center grayscale hover:grayscale-0 transition-all duration-500 opacity-60 hover:opacity-100">
                    <img src={src} alt="Partner" className="h-10 md:h-12 w-auto object-contain" />
                </div>
            ))}
        </div>
      </div>

      {/* Reviews */}
      <div className="max-w-7xl mx-auto px-4">
        <h3 className="text-2xl font-bold text-center mb-10">Real Client Results</h3>
        <div className="flex overflow-x-auto pb-8 space-x-6 no-scrollbar snap-x snap-mandatory">
            {REVIEWS.map((review) => (
                <motion.div 
                    key={review.id}
                    className="snap-center min-w-[300px] md:min-w-[400px] bg-white border border-slate-100 rounded-2xl p-8 shadow-lg flex flex-col justify-between"
                    whileHover={{ y: -5 }}
                >
                    <div>
                        <div className="flex mb-4">
                            {[...Array(review.stars)].map((_, i) => (
                                <Star key={i} className="w-5 h-5 text-gold-500 fill-current" />
                            ))}
                        </div>
                        <p className="text-slate-600 italic mb-6 leading-relaxed">"{review.text}"</p>
                    </div>
                    <div className="flex items-center space-x-3">
                         <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-500">
                            {review.name.charAt(0)}
                         </div>
                         <p className="font-bold text-slate-900 text-sm">{review.name}</p>
                    </div>
                </motion.div>
            ))}
        </div>
      </div>
    </section>
  );
};