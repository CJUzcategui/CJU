import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Building2, Users, Network, ChevronDown, ChevronUp, Play, X } from 'lucide-react';

const OFFICES = [
    "Plantation (HQ)", "Weston", "Pembroke Pines", "Coral Springs", "Fort Lauderdale",
    "Boca Raton", "Delray Beach", "Boynton Beach", "West Palm Beach", "Jupiter",
    "Wellington", "Hollywood", "Miami Lakes", "Aventura", "Coral Gables",
    "Doral", "Kendall", "Homestead", "Orlando", "Tampa"
];

const ALLIANCES = [
    "Remax", "Coldwell Banker", "Keller Williams", "Sotheby's International",
    "Engel & Völkers", "The Keyes Company", "eXp Realty", "Compass",
    "Douglas Elliman", "Berkshire Hathaway"
];

export const PowerSection: React.FC = () => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [videoModal, setVideoModal] = useState<string | null>(null);

  const toggleDropdown = (id: string) => {
    setActiveDropdown(activeDropdown === id ? null : id);
  };

  const videos = {
    scale: "M8Hx5D5ghag",
    brand: "jlOLDjImd2g"
  };

  return (
    <section className="py-24 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-gold-600 font-bold tracking-wider uppercase text-sm">The Powerhouse</span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-2">
            Backed by Florida's Largest Independent Brokerage
          </h2>
          <p className="mt-4 text-xl text-slate-600 max-w-3xl mx-auto">
            We are 4,500+ agents strong. When you hire Carlos, you hire a network that covers every inch of Miami, Broward, and Palm Beach.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Video 1: Partners & Growth */}
          <motion.div 
            className="group relative rounded-2xl overflow-hidden shadow-2xl bg-black cursor-pointer"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            onClick={() => setVideoModal(videos.scale)}
          >
             {/* Thumbnail Image */}
             <div className="relative w-full pt-[56.25%]">
                <img 
                    src={`https://img.youtube.com/vi/${videos.scale}/maxresdefault.jpg`} 
                    alt="Partners Meeting" 
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-80 group-hover:opacity-60"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/50 group-hover:scale-110 transition-transform duration-300">
                        <Play className="w-8 h-8 text-white fill-current ml-1" />
                    </div>
                </div>
             </div>
             <div className="p-6 bg-white relative z-10">
                <h3 className="text-xl font-bold text-slate-900">The Scale</h3>
                <p className="text-slate-600 mt-2">Partners meeting demonstrating our massive growth and network impact.</p>
             </div>
          </motion.div>

          {/* Video 2: Why United */}
          <motion.div 
            className="group relative rounded-2xl overflow-hidden shadow-2xl bg-black cursor-pointer"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            onClick={() => setVideoModal(videos.brand)}
          >
             {/* Thumbnail Image */}
             <div className="relative w-full pt-[56.25%]">
                <img 
                    src={`https://img.youtube.com/vi/${videos.brand}/maxresdefault.jpg`} 
                    alt="Why United" 
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-80 group-hover:opacity-60"
                />
                 <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/50 group-hover:scale-110 transition-transform duration-300">
                        <Play className="w-8 h-8 text-white fill-current ml-1" />
                    </div>
                </div>
             </div>
             <div className="p-6 bg-white relative z-10">
                <h3 className="text-xl font-bold text-slate-900">The Brand</h3>
                <p className="text-slate-600 mt-2">Why United Realty Group is the premier choice for agents and clients.</p>
             </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Stat 1: Agents */}
            <motion.div 
                className="flex flex-col items-center text-center p-6 bg-white rounded-xl shadow-sm border border-slate-100"
                whileHover={{ y: -5 }}
            >
                <div className="bg-slate-100 p-4 rounded-full mb-4">
                    <Users className="w-8 h-8 text-gold-600" />
                </div>
                <h4 className="text-xl font-bold text-slate-900">4,500+ Agents</h4>
                <p className="text-slate-500 mt-2">A massive referral network working for you.</p>
            </motion.div>

            {/* Stat 2: Offices (Interactive) */}
            <motion.div 
                className="relative flex flex-col items-center text-center p-6 bg-white rounded-xl shadow-sm border border-slate-100 cursor-pointer group hover:border-gold-400 transition-colors"
                onClick={() => toggleDropdown('offices')}
                whileHover={{ y: -5 }}
            >
                <div className="bg-slate-100 p-4 rounded-full mb-4 group-hover:bg-gold-50 transition-colors">
                    <Building2 className="w-8 h-8 text-gold-600" />
                </div>
                <div className="flex items-center space-x-2">
                    <h4 className="text-xl font-bold text-slate-900">20+ Offices</h4>
                    {activeDropdown === 'offices' ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>
                <p className="text-slate-500 mt-2">Strategic locations across South Florida.</p>
                
                <AnimatePresence>
                    {activeDropdown === 'offices' && (
                        <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl z-20 border border-slate-100 overflow-hidden"
                        >
                            <div className="p-4 grid grid-cols-2 gap-2 text-left bg-slate-50">
                                {OFFICES.map((office, i) => (
                                    <span key={i} className="text-xs text-slate-600 font-medium hover:text-gold-600">• {office}</span>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </motion.div>

            {/* Stat 3: Global Alliances (Interactive) */}
            <motion.div 
                className="relative flex flex-col items-center text-center p-6 bg-white rounded-xl shadow-sm border border-slate-100 cursor-pointer group hover:border-gold-400 transition-colors"
                onClick={() => toggleDropdown('alliances')}
                whileHover={{ y: -5 }}
            >
                <div className="bg-slate-100 p-4 rounded-full mb-4 group-hover:bg-gold-50 transition-colors">
                    <Network className="w-8 h-8 text-gold-600" />
                </div>
                <div className="flex items-center space-x-2">
                    <h4 className="text-xl font-bold text-slate-900">Global Alliances</h4>
                    {activeDropdown === 'alliances' ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>
                <p className="text-slate-500 mt-2">Direct connections in Spain & Europe.</p>

                <AnimatePresence>
                    {activeDropdown === 'alliances' && (
                        <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl z-20 border border-slate-100 overflow-hidden"
                        >
                            <div className="p-4 flex flex-col gap-2 text-left bg-slate-50">
                                <p className="text-xs font-bold text-slate-400 uppercase mb-2">We cooperate with:</p>
                                {ALLIANCES.map((alliance, i) => (
                                    <span key={i} className="text-sm text-slate-700 font-semibold border-b border-slate-100 last:border-0 pb-1 hover:text-gold-600">{alliance}</span>
                                ))}
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </motion.div>
        </div>
      </div>

      {/* Video Modal */}
      <AnimatePresence>
        {videoModal && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
                onClick={() => setVideoModal(null)}
            >
                <div className="relative w-full max-w-5xl aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-slate-700">
                    <button 
                        className="absolute top-4 right-4 z-50 bg-white/10 hover:bg-white/20 p-2 rounded-full text-white transition-colors"
                        onClick={(e) => { e.stopPropagation(); setVideoModal(null); }}
                    >
                        <X size={24} />
                    </button>
                    <iframe 
                        src={`https://www.youtube.com/embed/${videoModal}?autoplay=1&rel=0`} 
                        title="Video Player"
                        className="absolute inset-0 w-full h-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowFullScreen
                    ></iframe>
                </div>
            </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};