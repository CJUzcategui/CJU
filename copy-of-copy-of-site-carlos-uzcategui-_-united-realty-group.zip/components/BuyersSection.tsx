import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const BuyersSection: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <section className="py-24 bg-slate-50 relative">
        <div className="max-w-7xl mx-auto px-4 text-center">
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200"
            >
                <div className="grid md:grid-cols-2">
                    <div className="p-12 flex flex-col justify-center text-left">
                        <h2 className="text-4xl font-bold text-slate-900 mb-4">Find Your Dream Home</h2>
                        <p className="text-slate-600 text-lg mb-8">Access the Real-Time MLS. No delays. No outdated listings. Search like an agent.</p>
                        
                        <div 
                            onClick={() => setIsOpen(true)}
                            className="group cursor-pointer bg-slate-100 border-2 border-slate-200 rounded-2xl p-4 flex items-center hover:border-gold-500 transition-colors duration-300"
                        >
                            <Search className="text-slate-400 group-hover:text-gold-500 mr-4" />
                            <div className="flex-1">
                                <span className="text-slate-500 font-medium group-hover:text-slate-800">Start your search...</span>
                            </div>
                            <span className="bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-bold">Search</span>
                        </div>
                    </div>
                    <div className="relative h-64 md:h-auto bg-slate-900">
                         <img 
                            src="https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                            alt="Luxury Interior" 
                            className="absolute inset-0 w-full h-full object-cover opacity-80"
                         />
                         <div className="absolute inset-0 bg-gradient-to-l from-slate-900/50 to-transparent"></div>
                    </div>
                </div>
            </motion.div>
        </div>
      </section>

      {/* Full Screen IDX Modal */}
      <AnimatePresence>
        {isOpen && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] bg-slate-900/95 backdrop-blur-sm p-4 md:p-8"
            >
                <div className="w-full h-full bg-white rounded-2xl overflow-hidden relative shadow-2xl flex flex-col">
                    <div className="bg-slate-900 p-4 flex justify-between items-center">
                        <span className="text-white font-bold">United Realty Group MLS Access</span>
                        <button 
                            onClick={() => setIsOpen(false)}
                            className="bg-white/10 hover:bg-red-500 text-white p-2 rounded-full transition-colors"
                        >
                            <X size={24} />
                        </button>
                    </div>
                    <div className="flex-1 w-full relative">
                        <iframe 
                            src="https://sef.mlsmatrix.com/Matrix/public/IDX.aspx?idx=905b1cf2" 
                            className="absolute inset-0 w-full h-full border-0"
                            title="MLS Search"
                        />
                    </div>
                </div>
            </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};