import React from 'react';
import { motion } from 'framer-motion';
import { Handshake } from 'lucide-react';

export const JoinTeam: React.FC = () => {
  return (
    <section className="bg-slate-900 py-20 relative overflow-hidden">
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-gold-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl -ml-32 -mb-32"></div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 border border-slate-700 rounded-3xl p-8 md:p-16 flex flex-col md:flex-row items-center justify-between shadow-2xl">
          <div className="md:w-2/3 mb-8 md:mb-0">
            <motion.div
                 initial={{ opacity: 0, x: -20 }}
                 whileInView={{ opacity: 1, x: 0 }}
                 viewport={{ once: true }}
            >
                <div className="flex items-center space-x-3 mb-4">
                    <Handshake className="text-gold-500 w-8 h-8" />
                    <h3 className="text-gold-500 font-bold uppercase tracking-widest text-sm">Recruitment & Referrals</h3>
                </div>
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
                Agents: Let's Cooperate.
                </h2>
                <p className="text-lg text-slate-300 max-w-2xl">
                Join our referral network between South Florida and Spain. We offer competitive splits, global inventory access, and the backing of Florida's largest independent brokerage.
                </p>
            </motion.div>
          </div>
          
          <div className="md:w-1/3 flex justify-end">
            <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white text-slate-900 px-8 py-4 rounded-full font-bold text-lg hover:bg-gold-500 transition-colors duration-300 shadow-xl"
            >
                Partner with Us
            </motion.button>
          </div>
        </div>
      </div>
    </section>
  );
};