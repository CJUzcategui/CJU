import React from 'react';
import { MapPin, Phone, Mail, Send, MessageCircle, Home, ExternalLink } from 'lucide-react';

const SEO_CITIES = [
    "Weston", "Pembroke Pines", "Miramar", "Fort Lauderdale", "Plantation", 
    "Coral Springs", "Pompano Beach", "Parkland", "Hollywood", "Miami", 
    "Coral Gables", "Doral", "Aventura", "Miami Lakes", "Homestead", 
    "Brickell", "Pinecrest"
];

export const ContactFooter: React.FC = () => {
  return (
    <footer className="bg-slate-50 border-t border-slate-200">
      
      {/* Contact Form Section */}
      <div className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 className="text-3xl font-bold mb-4">Let's Discuss Your Real Estate Goals</h2>
                    <p className="text-slate-400 mb-8">Whether you're buying in South Florida or investing in Spain, I'm here to guide you. Send me a message directly.</p>
                    
                    <div className="space-y-4">
                        <a 
                            href="https://wa.me/19548656622?text=Hi%20Carlos,%20I%20am%20interested%20in%20South%20Florida%20real%20estate%20opportunities."
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors border border-white/10 group"
                        >
                            <div className="bg-green-500 p-2 rounded-full text-white group-hover:scale-110 transition-transform">
                                <MessageCircle size={24} />
                            </div>
                            <div>
                                <p className="text-xs text-slate-400 uppercase tracking-wider">Direct Cell (USA)</p>
                                <p className="font-bold text-lg">+1 (954) 865-6622</p>
                            </div>
                        </a>
                        
                        <a 
                            href="https://wa.me/34646853078?text=Hi%20Carlos,%20I%20am%20interested%20in%20investment%20opportunities%20in%20Spain."
                            target="_blank"
                            rel="noopener noreferrer" 
                            className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors border border-white/10 group"
                        >
                            <div className="bg-green-500 p-2 rounded-full text-white group-hover:scale-110 transition-transform">
                                <MessageCircle size={24} />
                            </div>
                            <div>
                                <p className="text-xs text-slate-400 uppercase tracking-wider">Spain (ES)</p>
                                <p className="font-bold text-lg">+34 646 853 078</p>
                            </div>
                        </a>

                        <div className="flex items-center space-x-4 p-4">
                            <Phone className="text-gold-500" />
                            <div>
                                <p className="text-xs text-slate-400 uppercase tracking-wider">United Realty Group Office</p>
                                <p className="font-bold text-lg text-white">954-450-2000</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-2xl p-8 text-slate-900 shadow-2xl">
                    <h3 className="text-xl font-bold mb-6">Send an Email</h3>
                    <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                        <div className="grid grid-cols-2 gap-4">
                            <input type="text" placeholder="Name" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 outline-none" />
                            <input type="tel" placeholder="Phone" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 outline-none" />
                        </div>
                        <input type="email" placeholder="Email Address" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 outline-none" />
                        <textarea placeholder="How can I help you?" rows={4} className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 focus:ring-2 focus:ring-gold-500 outline-none resize-none"></textarea>
                        <button className="w-full bg-gold-500 hover:bg-gold-600 text-white font-bold py-4 rounded-lg flex items-center justify-center space-x-2 transition-colors">
                            <span>Send Message</span>
                            <Send size={18} />
                        </button>
                    </form>
                    <p className="text-xs text-slate-400 mt-4 text-center">By clicking Send, you agree to receive emails/calls regarding your inquiry.</p>
                </div>
            </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
            
            {/* Column 1: Brand */}
            <div className="col-span-1 md:col-span-2">
                <div className="flex items-center space-x-2 mb-6">
                    {/* Reliable Logo Proxy */}
                    <img 
                        src="https://lh3.googleusercontent.com/d/1jQXdMm1SAa3dKndYKkO_umkR-SpOEKMY" 
                        alt="United Realty Group" 
                        className="h-12 object-contain"
                    />
                </div>
                <div className="flex items-start space-x-4 mb-6">
                    <MapPin className="w-5 h-5 text-gold-600 mt-1 flex-shrink-0" />
                    <div>
                        <p className="font-bold text-slate-900">Corporate Headquarters</p>
                        <p className="text-slate-600">1200 S. Pine Island Road, Suite 600<br/>Plantation, FL 33324</p>
                        <a 
                            href="https://www.google.com/maps/search/?api=1&query=United+Realty+Group+Plantation+FL" 
                            target="_blank"
                            rel="noreferrer"
                            className="text-gold-600 font-semibold hover:underline mt-1 inline-block text-sm"
                        >
                            Get Directions →
                        </a>
                    </div>
                </div>
                <div className="space-y-2">
                    <div className="flex items-center space-x-4">
                         <Mail className="w-5 h-5 text-gold-600" />
                         <a href="mailto:contact@carlosre.com" className="text-slate-600 font-medium hover:text-gold-600">contact@carlosre.com</a>
                    </div>
                    <div className="flex items-center space-x-4">
                         <ExternalLink className="w-5 h-5 text-gold-600" />
                         <a href="https://homesprofessional.com" target="_blank" rel="noopener noreferrer" className="text-slate-600 font-medium hover:text-gold-600">HomesProfessional.com</a>
                    </div>
                </div>
            </div>

            {/* Column 2: Partners */}
            <div className="col-span-1 md:col-span-2">
                <h4 className="font-bold text-slate-900 mb-6 uppercase tracking-wider text-sm">Trusted Partners</h4>
                <div className="grid grid-cols-2 gap-4">
                    <a 
                        href="https://certifiedhomeloans.com/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-center h-20 shadow-sm hover:shadow-md transition-shadow hover:border-gold-400 group"
                    >
                        <div className="text-center group-hover:scale-105 transition-transform">
                            <p className="text-slate-900 font-bold leading-tight">CERTIFIED</p>
                            <p className="text-slate-500 text-xs tracking-widest uppercase group-hover:text-gold-600">HOME LOANS</p>
                        </div>
                    </a>
                    <a 
                        href="https://sftafl.com/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-center h-20 shadow-sm hover:shadow-md transition-shadow hover:border-gold-400 group"
                    >
                        <div className="text-center group-hover:scale-105 transition-transform">
                            <p className="text-slate-900 font-serif italic text-2xl leading-none">sfta</p>
                            <p className="text-slate-500 text-[10px] tracking-widest uppercase group-hover:text-gold-600">South Florida Title</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        {/* SEO Cities */}
        <div className="border-t border-slate-200 py-8">
             <p className="text-xs text-slate-400 font-medium uppercase tracking-wider mb-2">Proudly Serving South Florida</p>
             <p className="text-xs text-slate-500 leading-relaxed">
                {SEO_CITIES.join(", ")}.
             </p>
        </div>

        {/* Compliance & Copyright */}
        <div className="border-t border-slate-200 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-400">
            <div className="flex items-center space-x-6 mb-4 md:mb-0">
                <div className="flex items-center space-x-2" title="Equal Housing Opportunity">
                    <Home size={20} />
                    <span>Equal Housing Opportunity</span>
                </div>
                <span>|</span>
                <span>Licensed Real Estate Agent</span>
            </div>
            <p>&copy; {new Date().getFullYear()} Carlos Uzcategui | United Realty Group.</p>
        </div>
        <p className="text-[10px] text-slate-300 mt-4 text-center md:text-left">
            United Realty Group is an Equal Opportunity Employer and supports the Fair Housing Act. All information is deemed reliable but not guaranteed.
        </p>
      </div>
    </footer>
  );
};