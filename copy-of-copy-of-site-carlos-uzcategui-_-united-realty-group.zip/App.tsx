import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { PowerSection } from './components/PowerSection';
import { JoinTeam } from './components/JoinTeam';
import { SellersSection } from './components/SellersSection';
import { BuyersSection } from './components/BuyersSection';
import { GlobalInvestors } from './components/GlobalInvestors';
import { ContactFooter } from './components/ContactFooter';

function App() {
  const [isGlobalMode, setIsGlobalMode] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      <Navbar isGlobal={isGlobalMode} setIsGlobal={setIsGlobalMode} />
      
      <main className="pt-28"> {/* Added padding for fixed topbar + navbar */}
        {/* Hero Section - Passes language state */}
        <Hero isGlobal={isGlobalMode} />
        
        {/* Power Section (Video Integration) */}
        <PowerSection />

        {/* Recruitment */}
        <JoinTeam />

        {/* Sellers Section */}
        <SellersSection />

        {/* Buyers Section */}
        <BuyersSection />

        {/* Global Investors - Highlighted when Global Mode is Active */}
        <div id="global-section" className={`transition-all duration-500 ${isGlobalMode ? 'ring-4 ring-gold-500 ring-offset-4' : ''}`}>
          <GlobalInvestors isGlobal={isGlobalMode} />
        </div>
      </main>

      <ContactFooter />
    </div>
  );
}

export default App;