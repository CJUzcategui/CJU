export interface Review {
  id: number;
  name: string;
  text: string;
  stars: number;
}

export interface RoiState {
  purchasePrice: number;
  monthlyRent: number;
  annualFees: number;
}

// Extend Window for webkitSpeechRecognition
declare global {
  interface Window {
    webkitSpeechRecognition: any;
  }
}